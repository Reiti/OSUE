var searchData=
[
  ['ispalindrome_2ec',['ispalindrome.c',['../ispalindrome_8c.html',1,'']]],
  ['ispalindrome_2eh',['ispalindrome.h',['../ispalindrome_8h.html',1,'']]]
];
