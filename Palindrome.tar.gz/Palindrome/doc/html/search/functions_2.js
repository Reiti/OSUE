var searchData=
[
  ['removenewline',['removeNewLine',['../ispalindrome_8c.html#aa8bb18887338f590f2c6628827162468',1,'removeNewLine(char *string):&#160;ispalindrome.c'],['../ispalindrome_8h.html#aa8bb18887338f590f2c6628827162468',1,'removeNewLine(char *string):&#160;ispalindrome.c']]],
  ['removespaces',['removeSpaces',['../ispalindrome_8c.html#a7911d8abfab6e6187332f2e796702db4',1,'removeSpaces(char *string):&#160;ispalindrome.c'],['../ispalindrome_8h.html#a7911d8abfab6e6187332f2e796702db4',1,'removeSpaces(char *string):&#160;ispalindrome.c']]]
];
