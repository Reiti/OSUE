var searchData=
[
  ['palindrome',['palindrome',['../ispalindrome_8c.html#adaa3758dd07a37622801b9bbe5b49017',1,'palindrome(char *string):&#160;ispalindrome.c'],['../ispalindrome_8h.html#adaa3758dd07a37622801b9bbe5b49017',1,'palindrome(char *string):&#160;ispalindrome.c']]]
];
